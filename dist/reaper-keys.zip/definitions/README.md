Check out the configuration section in the documentation if you need any help:
https://gwatcha.github.io/reaper-keys/
