return {
  track_mansion= {
    ["ga"] = "GetInputChannelName",
  },
}
